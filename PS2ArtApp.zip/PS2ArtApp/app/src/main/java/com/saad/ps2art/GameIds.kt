package com.saad.ps2art

object GameIds {
    private const val RAW = "https://raw.githubusercontent.com/xlenore/ps2-covers/main/covers/default"

    private val FIND_REGEX = Regex("([A-Z]{4})[_-](\\d{3})\\.(\\d{2})", RegexOption.IGNORE_CASE)
    private val EXACT_REGEX = Regex("^([A-Z]{4})_(\\d{3})\\.(\\d{2})$")

    private val REGIONS = mapOf(
        "SLUS" to "US", "SCUS" to "US",
        "SLES" to "EN", "SCES" to "EN", "SCED" to "EN", "SLED" to "EN",
        "SLPS" to "JA", "SLPM" to "JA", "SCPS" to "JA", "SCAJ" to "JA"
    )

    /** يستخرج كوداً بصيغة SLUS_200.62 من أي نص (مثل اسم ملف). */
    fun fromText(text: String): String? {
        val m = FIND_REGEX.find(text) ?: return null
        return "${m.groupValues[1]}_${m.groupValues[2]}.${m.groupValues[3]}".uppercase()
    }

    /** الروابط المحتملة للغلاف بالترتيب (الصيغة الصحيحة أولاً: SLUS-20062). */
    fun coverUrls(id: String): List<String> {
        val m = EXACT_REGEX.matchEntire(id) ?: return listOf("$RAW/$id.jpg")
        val prefix = m.groupValues[1]
        val a = m.groupValues[2]
        val b = m.groupValues[3]
        val urls = mutableListOf(
            "$RAW/$prefix-$a$b.jpg",
            "$RAW/$prefix-$a.$b.jpg",
            "$RAW/$id.jpg"
        )
        REGIONS[prefix]?.let { region ->
            urls.add("https://art.gametdb.com/ps2/cover/$region/$prefix-$a$b.jpg")
        }
        return urls
    }
}
