package com.saad.ps2art

import android.content.ContentResolver
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

class GameAdapter(
    private val scope: CoroutineScope,
    private val resolver: ContentResolver,
    private val items: List<Game>
) : RecyclerView.Adapter<GameAdapter.Holder>() {

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val cover: ImageView = view.findViewById(R.id.imgCover)
        val title: TextView = view.findViewById(R.id.txtTitle)
        val meta: TextView = view.findViewById(R.id.txtMeta)
        val status: TextView = view.findViewById(R.id.txtStatus)
    }

    private val cache = object : android.util.LruCache<String, Bitmap>(150) {}
    private val limiter = Semaphore(4)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_game, parent, false)
        return Holder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val game = items[position]
        val ctx = holder.itemView.context
        holder.title.text = game.title
        holder.meta.text = "${game.gameId}  •  ${game.format}"

        val ok = ctx.getString(R.string.status_ok)
        val no = ctx.getString(R.string.status_missing)
        holder.status.text = "${ctx.getString(R.string.cover_label)} ${if (game.hasCover) ok else no}    " +
            "${ctx.getString(R.string.icon_label)} ${if (game.hasIcon) ok else no}"
        holder.status.setTextColor(
            if (game.hasCover && game.hasIcon) 0xFF34D399.toInt() else 0xFFF87171.toInt()
        )

        val key = "${game.gameId}:${game.hasCover}"
        holder.cover.tag = key
        val cached = cache.get(key)
        if (cached != null) {
            holder.cover.setImageBitmap(cached)
            return
        }
        holder.cover.setImageDrawable(null)
        scope.launch {
            val bitmap = limiter.withPermit {
                withContext(Dispatchers.IO) { loadThumb(game) }
            }
            if (bitmap != null) {
                cache.put(key, bitmap)
                if (holder.cover.tag == key) holder.cover.setImageBitmap(bitmap)
            }
        }
    }

    private suspend fun loadThumb(game: Game): Bitmap? {
        return try {
            val uri = game.coverUri
            val data: ByteArray? = if (game.hasCover && uri != null) {
                resolver.openInputStream(uri)?.use { it.readBytes() }
            } else {
                ArtworkClient.fetchCover(game.gameId)
            }
            if (data == null) null else ArtworkClient.decodeSampled(data, 160)
        } catch (_: Exception) {
            null
        }
    }
}
