package com.saad.ps2art

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private var storage: UsbStorage? = null
    private val allGames = mutableListOf<Game>()
    private val shownGames = mutableListOf<Game>()
    private lateinit var adapter: GameAdapter
    private var job: Job? = null

    private lateinit var btnPick: Button
    private lateinit var btnMissing: Button
    private lateinit var btnAll: Button
    private lateinit var btnCancel: Button
    private lateinit var txtStats: TextView
    private lateinit var txtProgress: TextView
    private lateinit var txtEmpty: TextView
    private lateinit var progressBox: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var edtSearch: EditText
    private lateinit var chkMissing: CheckBox

    private val pickTree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) onTreePicked(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPick = findViewById(R.id.btnPick)
        btnMissing = findViewById(R.id.btnMissing)
        btnAll = findViewById(R.id.btnAll)
        btnCancel = findViewById(R.id.btnCancel)
        txtStats = findViewById(R.id.txtStats)
        txtProgress = findViewById(R.id.txtProgress)
        txtEmpty = findViewById(R.id.txtEmpty)
        progressBox = findViewById(R.id.progressBox)
        progressBar = findViewById(R.id.progressBar)
        edtSearch = findViewById(R.id.edtSearch)
        chkMissing = findViewById(R.id.chkMissing)

        adapter = GameAdapter(lifecycleScope, contentResolver, shownGames)
        val recycler = findViewById<RecyclerView>(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        btnPick.setOnClickListener { pickTree.launch(null) }
        btnMissing.setOnClickListener { download(overwrite = false) }
        btnAll.setOnClickListener { download(overwrite = true) }
        btnCancel.setOnClickListener {
            job?.cancel()
            setBusy(false)
        }

        edtSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = applyFilter()
        })
        chkMissing.setOnCheckedChangeListener { _, _ -> applyFilter() }

        applyFilter()
    }

    private fun onTreePicked(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
            // بعض الأجهزة لا تدعم الإذن الدائم؛ نكمل بإذن الجلسة.
        }
        val root = DocumentFile.fromTreeUri(this, uri)
        if (root == null) {
            Toast.makeText(this, R.string.scan_error, Toast.LENGTH_LONG).show()
            return
        }
        storage = UsbStorage(this, root)
        scan()
    }

    private fun scan() {
        val st = storage ?: return
        job?.cancel()
        job = lifecycleScope.launch {
            setBusy(true)
            txtProgress.text = getString(R.string.scanning)
            progressBar.isIndeterminate = true
            val result: List<Game> = try {
                withContext(Dispatchers.IO) { st.scan() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, R.string.scan_error, Toast.LENGTH_LONG).show()
                emptyList()
            }
            progressBar.isIndeterminate = false
            allGames.clear()
            allGames.addAll(result)
            setBusy(false)
            if (result.isEmpty()) {
                Toast.makeText(this@MainActivity, R.string.no_games, Toast.LENGTH_LONG).show()
            }
            applyFilter()
        }
    }

    private fun download(overwrite: Boolean) {
        val st = storage ?: return
        val targets = if (overwrite) allGames.toList() else allGames.filter { !it.hasCover || !it.hasIcon }
        if (targets.isEmpty()) {
            Toast.makeText(this, R.string.all_done, Toast.LENGTH_LONG).show()
            return
        }

        job?.cancel()
        job = lifecycleScope.launch {
            setBusy(true)
            progressBar.isIndeterminate = false
            progressBar.max = targets.size
            progressBar.progress = 0

            val dirs = try {
                withContext(Dispatchers.IO) { st.ensureArtDirs() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, R.string.dirs_error, Toast.LENGTH_LONG).show()
                setBusy(false)
                return@launch
            }

            var ok = 0
            var fail = 0
            var done = 0
            val limiter = Semaphore(4)

            try {
                coroutineScope {
                    for (game in targets) {
                        launch(Dispatchers.IO) {
                            limiter.withPermit {
                                val success = try {
                                    processGame(st, dirs, game, overwrite)
                                } catch (e: CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    false
                                }
                                withContext(Dispatchers.Main) {
                                    if (success) ok++ else fail++
                                    done++
                                    progressBar.progress = done
                                    txtProgress.text = "$done / ${targets.size}  —  ${game.title}"
                                    if (done % 5 == 0 || done == targets.size) applyFilter()
                                }
                            }
                        }
                    }
                }
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.result, ok, fail),
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                setBusy(false)
                applyFilter()
            }
        }
    }

    private suspend fun processGame(
        st: UsbStorage,
        dirs: Pair<DocumentFile, DocumentFile>,
        game: Game,
        overwrite: Boolean
    ): Boolean {
        val needCover = overwrite || !game.hasCover
        val needIcon = overwrite || !game.hasIcon

        val source: ByteArray? = when {
            needCover -> ArtworkClient.fetchCover(game.gameId)
            needIcon -> game.coverUri?.let { uri ->
                contentResolver.openInputStream(uri)?.use { it.readBytes() }
            }
            else -> null
        }
        if (source == null) return false

        if (needCover) {
            val file = st.writeFile(dirs.first, "${game.gameId}_COV.jpg", "image/jpeg", ArtworkClient.toJpeg(source))
            game.hasCover = true
            game.coverUri = file.uri
        }
        if (needIcon) {
            st.writeFile(dirs.second, "${game.gameId}_ICO.png", "image/png", ArtworkClient.toIcon(source))
            game.hasIcon = true
        }
        return true
    }

    private fun setBusy(busy: Boolean) {
        val hasStorage = storage != null
        btnPick.isEnabled = !busy
        btnMissing.isEnabled = !busy && hasStorage && allGames.isNotEmpty()
        btnAll.isEnabled = !busy && hasStorage && allGames.isNotEmpty()
        progressBox.visibility = if (busy) View.VISIBLE else View.GONE
    }

    private fun applyFilter() {
        val query = edtSearch.text.toString().trim().lowercase()
        val onlyMissing = chkMissing.isChecked

        shownGames.clear()
        shownGames.addAll(
            allGames.filter { game ->
                val matches = query.isEmpty() ||
                    game.title.lowercase().contains(query) ||
                    game.gameId.lowercase().contains(query)
                val missingOk = !onlyMissing || !game.hasCover || !game.hasIcon
                matches && missingOk
            }
        )
        adapter.notifyDataSetChanged()

        val missing = allGames.count { !it.hasCover || !it.hasIcon }
        txtStats.text = getString(R.string.stats, allGames.size, missing)
        txtEmpty.visibility = if (allGames.isEmpty()) View.VISIBLE else View.GONE

        if (progressBox.visibility != View.VISIBLE) {
            val ready = storage != null && allGames.isNotEmpty()
            btnMissing.isEnabled = ready
            btnAll.isEnabled = ready
        }
    }
}
