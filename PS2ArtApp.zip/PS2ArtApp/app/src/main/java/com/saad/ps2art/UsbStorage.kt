package com.saad.ps2art

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import java.io.IOException

/** كل العمليات على الفلاش تتم عبر Storage Access Framework (بدون صلاحيات تخزين عامة). */
class UsbStorage(private val context: Context, private val root: DocumentFile) {

    private fun child(parent: DocumentFile, name: String): DocumentFile? =
        parent.listFiles().firstOrNull { it.name.equals(name, ignoreCase = true) }

    fun scan(): List<Game> {
        val games = mutableListOf<Game>()

        for (folderName in listOf("DVD", "CD")) {
            val folder = child(root, folderName) ?: continue
            if (!folder.isDirectory) continue
            for (file in folder.listFiles()) {
                val name = file.name ?: continue
                if (!file.isFile || !name.endsWith(".iso", ignoreCase = true)) continue
                val id = IsoReader.readGameId(context, file.uri, name) ?: continue
                val title = name
                    .replace(Regex("\\.iso$", RegexOption.IGNORE_CASE), "")
                    .replace(Regex("^[A-Z]{4}[_-]\\d{3}\\.\\d{2}\\.", RegexOption.IGNORE_CASE), "")
                games.add(Game(title = title, gameId = id, format = "ISO"))
            }
        }

        child(root, "ul.cfg")?.let { cfg ->
            if (cfg.isFile) games.addAll(IsoReader.parseUlCfg(context, cfg.uri))
        }

        val unique = games.distinctBy { "${it.format}:${it.gameId}" }
        checkArtwork(unique)
        return unique.sortedBy { it.title.lowercase() }
    }

    private fun namesOf(folderName: String): Map<String, DocumentFile> {
        val folder = child(root, folderName) ?: return emptyMap()
        if (!folder.isDirectory) return emptyMap()
        val map = HashMap<String, DocumentFile>()
        for (file in folder.listFiles()) {
            val name = file.name ?: continue
            map[name.uppercase()] = file
        }
        return map
    }

    private fun checkArtwork(games: List<Game>) {
        val art = namesOf("ART")
        val icons = namesOf("ICONS")
        for (game in games) {
            val id = game.gameId.uppercase()
            val coverFile = listOf("${id}_COV.JPG", "${id}_COV.PNG", "$id.JPG", "$id.PNG")
                .firstNotNullOfOrNull { art[it] }
            game.hasCover = coverFile != null
            game.coverUri = coverFile?.uri
            game.hasIcon = listOf("${id}_ICO.PNG", "$id.PNG", "$id.JPG").any { icons.containsKey(it) }
        }
    }

    /** ينشئ ART وICONS إن لم يوجدا. */
    fun ensureArtDirs(): Pair<DocumentFile, DocumentFile> {
        val art = child(root, "ART") ?: root.createDirectory("ART") ?: throw IOException("ART")
        val icons = child(root, "ICONS") ?: root.createDirectory("ICONS") ?: throw IOException("ICONS")
        return Pair(art, icons)
    }

    fun writeFile(dir: DocumentFile, name: String, mime: String, bytes: ByteArray): DocumentFile {
        dir.findFile(name)?.delete()
        val file = dir.createFile(mime, name) ?: throw IOException("create $name")
        val stream = context.contentResolver.openOutputStream(file.uri, "wt")
            ?: throw IOException("open $name")
        stream.use { it.write(bytes) }
        return file
    }
}
