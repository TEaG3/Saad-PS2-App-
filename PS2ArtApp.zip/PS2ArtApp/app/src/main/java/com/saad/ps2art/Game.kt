package com.saad.ps2art

import android.net.Uri

data class Game(
    val title: String,
    val gameId: String,
    val format: String,
    @Volatile var hasCover: Boolean = false,
    @Volatile var hasIcon: Boolean = false,
    @Volatile var coverUri: Uri? = null
)
