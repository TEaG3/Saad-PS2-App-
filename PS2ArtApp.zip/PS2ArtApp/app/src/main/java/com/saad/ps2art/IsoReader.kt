package com.saad.ps2art

import android.content.Context
import android.net.Uri
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/** يقرأ كود اللعبة من داخل ملف ISO (SYSTEM.CNF) بدون تحميل الملف كاملاً. */
object IsoReader {
    private const val SECTOR = 2048

    private val BOOT_REGEX = Regex(
        "BOOT2?\\s*=\\s*cdrom0:\\\\?([A-Z]{4}[_-]\\d{3}\\.\\d{2})",
        RegexOption.IGNORE_CASE
    )
    private val GENERIC_REGEX = Regex("[SPL][LCB][UEPKAJ][SDMXP]_\\d{3}\\.\\d{2}", RegexOption.IGNORE_CASE)

    fun readGameId(context: Context, uri: Uri, fileName: String): String? {
        try {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            if (pfd != null) {
                pfd.use {
                    FileInputStream(it.fileDescriptor).use { input ->
                        val channel = input.channel
                        val fromCnf = fromSystemCnf(channel)
                        if (fromCnf != null) return fromCnf
                        val fromScan = scanHead(channel)
                        if (fromScan != null) return fromScan
                    }
                }
            }
        } catch (_: Exception) {
            // نرجع لاسم الملف
        }
        return GameIds.fromText(fileName)
    }

    private fun readAt(channel: FileChannel, position: Long, length: Int): ByteArray {
        val buffer = ByteBuffer.allocate(length)
        channel.position(position)
        while (buffer.hasRemaining()) {
            if (channel.read(buffer) < 0) break
        }
        return buffer.array().copyOf(buffer.position())
    }

    private fun fromSystemCnf(channel: FileChannel): String? {
        val pvd = readAt(channel, 16L * SECTOR, SECTOR)
        if (pvd.size < SECTOR || pvd[0].toInt() != 1) return null

        val pvdBuf = ByteBuffer.wrap(pvd).order(ByteOrder.LITTLE_ENDIAN)
        val rootLba = pvdBuf.getInt(156 + 2).toLong() and 0xFFFFFFFFL
        val rootSize = pvdBuf.getInt(156 + 10).toLong() and 0xFFFFFFFFL

        val dir = readAt(channel, rootLba * SECTOR, minOf(rootSize, 65536L).toInt())
        val dirBuf = ByteBuffer.wrap(dir).order(ByteOrder.LITTLE_ENDIAN)

        var off = 0
        while (off + 34 <= dir.size) {
            val len = dir[off].toInt() and 0xFF
            if (len == 0) {
                off = (off / SECTOR + 1) * SECTOR
                continue
            }
            val nameLen = dir[off + 32].toInt() and 0xFF
            if (off + 33 + nameLen > dir.size) break
            val name = String(dir, off + 33, nameLen, Charsets.US_ASCII)
            if (name.uppercase().startsWith("SYSTEM.CNF")) {
                val lba = dirBuf.getInt(off + 2).toLong() and 0xFFFFFFFFL
                val size = minOf(dirBuf.getInt(off + 10).toLong() and 0xFFFFFFFFL, 4096L).toInt()
                val text = String(readAt(channel, lba * SECTOR, size), Charsets.US_ASCII)
                val m = BOOT_REGEX.find(text) ?: return null
                return m.groupValues[1].uppercase().replace('-', '_')
            }
            off += len
        }
        return null
    }

    private fun scanHead(channel: FileChannel): String? {
        val size = minOf(channel.size(), 4L * 1024 * 1024).toInt()
        if (size <= 0) return null
        val text = String(readAt(channel, 0, size), Charsets.ISO_8859_1)
        BOOT_REGEX.find(text)?.let { return it.groupValues[1].uppercase().replace('-', '_') }
        GENERIC_REGEX.find(text)?.let { return it.value.uppercase() }
        return null
    }

    /** يقرأ ملف ul.cfg: كل سجل 64 بايت (الاسم 32 + الكود 15 + بيانات أخرى). */
    fun parseUlCfg(context: Context, uri: Uri): List<Game> {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return emptyList()
        val result = mutableListOf<Game>()
        val idPattern = Regex("^[A-Z]{4}_\\d{3}\\.\\d{2}$")
        var off = 0
        while (off + 64 <= bytes.size) {
            val name = cString(bytes, off, 32).trim()
            val rawId = cString(bytes, off + 32, 15).trim()
            val id = rawId.replace(Regex("^ul\\.", RegexOption.IGNORE_CASE), "").uppercase()
            if (name.isNotEmpty() && idPattern.matches(id)) {
                result.add(Game(title = name, gameId = id, format = "UL"))
            }
            off += 64
        }
        return result
    }

    private fun cString(bytes: ByteArray, offset: Int, length: Int): String {
        var end = offset
        while (end < offset + length && bytes[end].toInt() != 0) end++
        return String(bytes, offset, end - offset, Charsets.UTF_8)
    }
}
