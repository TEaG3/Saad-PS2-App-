package com.saad.ps2art

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object ArtworkClient {
    private const val ICON_MAX_SIDE = 128

    /** ينزّل أول غلاف صالح من الروابط المحتملة، أو null إن لم يوجد. */
    suspend fun fetchCover(gameId: String): ByteArray? = withContext(Dispatchers.IO) {
        for (url in GameIds.coverUrls(gameId)) {
            val data = download(url) ?: continue
            if (isValidImage(data)) return@withContext data
        }
        null
    }

    private fun download(address: String): ByteArray? {
        return try {
            val connection = URL(address).openConnection() as HttpURLConnection
            try {
                connection.connectTimeout = 10_000
                connection.readTimeout = 12_000
                connection.instanceFollowRedirects = true
                if (connection.responseCode == 200) connection.inputStream.use { it.readBytes() } else null
            } finally {
                connection.disconnect()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun isValidImage(data: ByteArray): Boolean {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, options)
        return options.outWidth > 0 && options.outHeight > 0
    }

    /** غلاف JPEG حقيقي: نُبقي الملف كما هو إن كان JPEG، وإلا نحوّله على خلفية بيضاء. */
    fun toJpeg(data: ByteArray): ByteArray {
        val isJpeg = data.size > 2 && data[0] == 0xFF.toByte() && data[1] == 0xD8.toByte()
        if (isJpeg) return data
        val source = BitmapFactory.decodeByteArray(data, 0, data.size) ?: return data
        val flat = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(flat)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(source, 0f, 0f, null)
        val out = ByteArrayOutputStream()
        flat.compress(Bitmap.CompressFormat.JPEG, 92, out)
        source.recycle()
        flat.recycle()
        return out.toByteArray()
    }

    /** أيقونة PNG حقيقية مصغّرة (أكبر بُعد 128 بكسل). */
    fun toIcon(data: ByteArray): ByteArray {
        val source = BitmapFactory.decodeByteArray(data, 0, data.size) ?: return data
        val scale = minOf(1f, ICON_MAX_SIDE.toFloat() / maxOf(source.width, source.height))
        val width = maxOf(1, Math.round(source.width * scale))
        val height = maxOf(1, Math.round(source.height * scale))
        val scaled = Bitmap.createScaledBitmap(source, width, height, true)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.PNG, 100, out)
        if (scaled !== source) scaled.recycle()
        source.recycle()
        return out.toByteArray()
    }

    /** فك ترميز مصغّر للمعاينة في القائمة لتوفير الذاكرة. */
    fun decodeSampled(data: ByteArray, targetWidth: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= targetWidth) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(data, 0, data.size, options)
    }
}
